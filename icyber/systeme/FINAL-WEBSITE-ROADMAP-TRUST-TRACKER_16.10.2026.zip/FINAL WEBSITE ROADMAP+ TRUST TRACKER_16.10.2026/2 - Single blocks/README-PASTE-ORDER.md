# Wealth shop · systeme.io blocks (journey-website style)

Paste each file into its own **Custom HTML/CSS/JS** element, in this order. Set every section and row background to **Clear** and padding to 0, so the light/dark page background shows through.

1. `01-top-buttons.html`: Main Page · My Amazon Store · Tools and Resources · All journeys · Dark/White mode
2. `02-hero-portrait.html`: upload `liliane-portrait.png`, then replace `PASTE-YOUR-PHOTO-URL-HERE` with its link
3. `03-bundle-card.html`: upload `bundle-website-card.png`, `product-wealth-roadmap.png` and `product-trust-tracker-pro.png`, then replace `PASTE-ROADMAP-IMAGE-URL`, `PASTE-ROADMAP-ONLY-IMAGE-URL` and `PASTE-TRACKER-IMAGE-URL` with their links. The card already has two "Get the bundle – €39" buttons linking to your store (cybercnslt.com/4dd2503b), so you don't need to add one in systeme.io
4. `04-free-trust-sheet-card.html`: TRUST Sheet – Financial Tracker (links to /free-financial-trust-sheet). Upload `trust-sheet-laptop.webp` and replace `PASTE-TRUST-IMAGE-URL` with its link
5. `05-about-liliane-card.html`: "Hey, I'm Liliane"
   (Upload `liliane-journey.webp` and put its link where block 5 says `PASTE-JOURNEY-IMAGE-URL`.)
6. `06-three-road-cards.html`: Start Your Journey Today, the fork road and Career · Business · Wealth (same layout as your journey hub)


## Links (already filled in)
| Button | Goes to |
|---|---|
| Main Page | https://www.cybercnslt.com/ |
| My Amazon Store | https://amzn.to/3QzHB0n |
| Tools and Resources | https://www.cybercnslt.com/#tools |
| All journeys | https://www.cybercnslt.com/#journeys |
| Grow Your Career / Business / Wealth | https://www.cybercnslt.com/#cybersecurity, #business, #finances |
| Get the free sheet | https://www.cybercnslt.com/free-financial-trust-sheet |

Dark mode uses the same saved choice as your journey website, so a visitor who picked dark mode there sees this page in dark mode too.
